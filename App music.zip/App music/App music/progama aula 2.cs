﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace App_music
{
    internal class Program
    {
        static void Main(string[] args)
        {
         
            string nome = "";
            float km, lt, R;
            WriteLine("Digite o modelo do seu carro");
            nome = ReadLine();
            WriteLine("Digite a dsitancia percorrida");
            km = float.Parse(ReadLine());
            WriteLine("Digite a quantidade de gasolina");
            lt = float.Parse(ReadLine());
            R = (km / lt);
            WriteLine($" O resultado foi {nome} é: {R}");
            ReadKey();
            




        }

    }
}
